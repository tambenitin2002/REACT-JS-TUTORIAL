import React from 'react'

const LeftNav = () => {
  return (
    <div>
        <img src="../public/foodlogo.png" alt="" style={{height:90 , width:130}} />
    </div>
  )
}

export default LeftNav