import React from 'react'
import Contextapi from './Contextapi'
import Home from './Home'


const FoodDriver = () => {
  return (
    <Contextapi>
   <Home/>
   </Contextapi>
  )
}

export default FoodDriver